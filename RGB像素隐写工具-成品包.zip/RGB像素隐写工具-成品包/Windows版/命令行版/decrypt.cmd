@echo off
rem RGB Stego - decryption wrapper.
rem Keep this file ASCII-only: cmd.exe re-parses a batch file byte-wise after any
rem codepage switch, which corrupts multi-byte characters in comments.
rem Usage: decrypt.cmd -i <encrypted png> -o <output path> [options]
rem All user-facing messages (Chinese) come from decrypt.mjs, not from this file.
where node >nul 2>nul
if errorlevel 1 (
  echo Node.js not found. Install it from https://nodejs.org, or use the GUI version instead.
  exit /b 1
)
node "%~dp0decrypt.mjs" %*
