@echo off
rem RGB Stego - batch encryption over a folder.
rem Keep this file ASCII-only (cmd.exe re-parses batch files byte-wise).
rem Usage: <this file> <source folder> <output folder> [options]
rem Example: encrypt a whole folder with 8x8 blocks, overwriting existing output.
rem   batch-encrypt.cmd D:\docs D:\send -b 8 -f
where node >nul 2>nul
if errorlevel 1 (
  echo Node.js not found. Install it from https://nodejs.org.
  exit /b 1
)
node "%~dp0batch-encrypt.mjs" %*
