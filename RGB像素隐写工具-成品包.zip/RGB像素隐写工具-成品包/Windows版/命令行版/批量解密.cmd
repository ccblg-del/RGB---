@echo off
rem RGB Stego - batch decryption over a folder.
rem Keep this file ASCII-only (cmd.exe re-parses batch files byte-wise).
rem Usage: <this file> <encrypted image folder> <output folder> [options]
rem Example: restore every PNG in D:\send back into D:\restored.
rem   batch-decrypt.cmd D:\send D:\restored -f
where node >nul 2>nul
if errorlevel 1 (
  echo Node.js not found. Install it from https://nodejs.org.
  exit /b 1
)
node "%~dp0batch-decrypt.mjs" %*
