#!/bin/sh
# RGB 像素隐写工具 · 卸载脚本（Linux / macOS）
#
# 等价于： sh install.sh --uninstall
# 只删除本工具安装的文件（~/.local/share/rgb-stego、命令行软链接、桌面菜单项），
# 你用它加密或还原出来的图片、文件不受影响。

set -eu

SELF=$0
while [ -h "$SELF" ]; do
  LINK=$(readlink "$SELF")
  case $LINK in
    /*) SELF=$LINK ;;
    *) SELF=$(dirname -- "$SELF")/$LINK ;;
  esac
done
DIR=$(CDPATH= cd -- "$(dirname -- "$SELF")" && pwd)

if [ -f "$DIR/install.sh" ]; then
  exec sh "$DIR/install.sh" --uninstall
fi

# 兜底：找不到 install.sh 时按默认位置直接删
PREFIX_DIR="${XDG_DATA_HOME:-$HOME/.local/share}"
rm -f "$HOME/.local/bin/rgb-stego" \
      "$HOME/.local/bin/rgb-stego-encrypt" \
      "$HOME/.local/bin/rgb-stego-decrypt" \
      "$HOME/.local/bin/rgb-stego-batch-encrypt" \
      "$HOME/.local/bin/rgb-stego-batch-decrypt"
rm -f "$PREFIX_DIR/applications/rgb-stego.desktop"
rm -rf "$PREFIX_DIR/rgb-stego"
echo "已卸载。"
