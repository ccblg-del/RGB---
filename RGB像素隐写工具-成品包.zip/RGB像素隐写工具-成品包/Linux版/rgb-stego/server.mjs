/**
 * 可选：本地静态服务，用 http://127.0.0.1 打开工具。
 * 本地地址属于安全上下文，浏览器可启用 File System Access API，
 * 从而支持“另存为”对话框，自定义保存位置与文件名。
 *
 * 用法：node server.mjs [端口] [--no-open]
 */
import http from 'node:http';
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { spawn } from 'node:child_process';

const root = path.dirname(fileURLToPath(import.meta.url));
const portArg = process.argv.slice(2).find((a) => /^\d+$/.test(a));
const port = Number(process.env.PORT || portArg || 8765);
const noOpen = process.argv.includes('--no-open');

const MIME = {
  '.html': 'text/html; charset=utf-8',
  '.js': 'text/javascript; charset=utf-8',
  '.mjs': 'text/javascript; charset=utf-8',
  '.css': 'text/css; charset=utf-8',
  '.json': 'application/json; charset=utf-8',
  '.png': 'image/png',
  '.txt': 'text/plain; charset=utf-8',
  '.md': 'text/markdown; charset=utf-8'
};

const server = http.createServer((req, res) => {
  let urlPath = decodeURIComponent((req.url || '/').split('?')[0]);
  if (urlPath === '/' || urlPath === '') urlPath = '/index.html';
  const safe = path.normalize(urlPath).replace(/^[\\/]+/, '');
  const full = path.join(root, safe);
  if (!full.startsWith(root)) {
    res.writeHead(403, { 'Content-Type': 'text/plain; charset=utf-8' });
    res.end('403 禁止访问');
    return;
  }
  fs.readFile(full, (err, data) => {
    if (err) {
      res.writeHead(404, { 'Content-Type': 'text/plain; charset=utf-8' });
      res.end('404 未找到：' + safe);
      return;
    }
    res.writeHead(200, {
      'Content-Type': MIME[path.extname(full).toLowerCase()] || 'application/octet-stream',
      'Cache-Control': 'no-store'
    });
    res.end(data);
  });
});

server.on('error', (err) => {
  console.error('启动失败：' + err.message);
  if (err.code === 'EADDRINUSE') {
    console.error(`端口 ${port} 已被占用，换一个端口重试：node server.mjs 8899`);
  }
  process.exit(1);
});

server.listen(port, '127.0.0.1', () => {
  const url = `http://127.0.0.1:${port}/`;
  console.log('');
  console.log('  RGB 像素隐写工具已启动：' + url);
  console.log('  在此窗口按 Ctrl+C 可停止服务。');
  console.log('');
  if (!noOpen) openBrowser(url);
});

/**
 * 打开默认浏览器。
 * 关键：spawn 失败（Linux 上没有 xdg-open）会触发 'error' 事件，
 * 如果不监听，Node 会抛出未捕获异常直接把服务进程带崩。
 */
function openBrowser(url) {
  let cmd;
  let args;
  if (process.platform === 'win32') {
    cmd = 'cmd';
    args = ['/c', 'start', '', url];
  } else if (process.platform === 'darwin') {
    cmd = 'open';
    args = [url];
  } else {
    cmd = 'xdg-open';
    args = [url];
  }

  const warn = function () {
    console.log('  （未能自动打开浏览器，请手动访问上面的地址）');
  };

  try {
    const child = spawn(cmd, args, { stdio: 'ignore', detached: true });
    child.on('error', warn);
    child.unref();
  } catch (err) {
    warn();
  }
}
