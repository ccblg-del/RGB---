#!/usr/bin/env node
/**
 * 批量解密脚本
 *
 * 把加密图片文件夹里的每张 PNG 还原成原始文件，放到输出文件夹里。
 * 文件名去掉结尾的 .png，因此 batch-encrypt.mjs 生成的 合同.pdf.png 会还原成 合同.pdf。
 *
 * 用法：
 *   node batch-decrypt.mjs <加密图片文件夹> <输出文件夹> [选项]
 *
 * 选项：
 *   -f, --force          覆盖已存在的输出文件
 *   -r, --recursive      连同子文件夹一起处理（保持相对目录结构）
 *   -q, --quiet          只输出汇总，不逐条打印
 *   -h, --help           显示帮助
 *
 * 退出码：0 全部成功 / 1 用法错误 / 2 有文件处理失败或校验和不匹配
 */
import fs from 'node:fs';
import path from 'node:path';
import { spawnSync } from 'node:child_process';
import { fileURLToPath } from 'node:url';
import { EX } from './lib/cli-common.mjs';

const here = path.dirname(fileURLToPath(import.meta.url));
const DECRYPT = path.join(here, 'decrypt.mjs');

const USAGE = `
批量解密脚本

用法
  node batch-decrypt.mjs <加密图片文件夹> <输出文件夹> [选项]

选项
  -f, --force          覆盖已存在的输出文件
  -r, --recursive      连同子文件夹一起处理（保持相对目录结构）
  -q, --quiet          只输出汇总
  -h, --help           显示本帮助

示例
  node batch-decrypt.mjs ${EX.outDir} ${EX.backDir}
  node batch-decrypt.mjs ${EX.outDir} ${EX.backDir} -f -r
`.trimStart();

function usageError(msg) {
  console.error('参数错误：' + msg);
  console.error('运行 node batch-decrypt.mjs --help 查看用法。');
  process.exit(1);
}

/* ---------- 参数 ---------- */
const argv = process.argv.slice(2);
const opts = { force: false, recursive: false, quiet: false };
const positional = [];

for (let i = 0; i < argv.length; i++) {
  const a = argv[i];
  if (a === '-h' || a === '--help') { console.log(USAGE); process.exit(0); }
  else if (a === '-f' || a === '--force') { opts.force = true; }
  else if (a === '-r' || a === '--recursive') { opts.recursive = true; }
  else if (a === '-q' || a === '--quiet') { opts.quiet = true; }
  else if (a.startsWith('-') && a.length > 1) { usageError('未知选项：' + a); }
  else { positional.push(a); }
}

if (positional.length < 2) usageError('需要指定 <加密图片文件夹> 和 <输出文件夹>。');
if (positional.length > 2) usageError('多余的参数：' + positional.slice(2).join(' '));

const srcDir = path.resolve(positional[0]);
const dstDir = path.resolve(positional[1]);

if (!fs.existsSync(srcDir)) { console.error('找不到加密图片文件夹：' + srcDir); process.exit(2); }
if (!fs.statSync(srcDir).isDirectory()) { console.error('不是文件夹：' + srcDir); process.exit(2); }

/* ---------- 收集 PNG ---------- */
function collect(dir, base, out) {
  for (const entry of fs.readdirSync(dir, { withFileTypes: true })) {
    const full = path.join(dir, entry.name);
    const rel = base ? path.join(base, entry.name) : entry.name;
    if (entry.isDirectory()) {
      if (opts.recursive) collect(full, rel, out);
    } else if (entry.isFile() && entry.name.toLowerCase().endsWith('.png')) {
      out.push({ full: full, rel: rel });
    }
  }
  return out;
}

const files = collect(srcDir, '', []);
if (files.length === 0) {
  console.error('文件夹里没有 PNG 图片：' + srcDir);
  process.exit(2);
}

fs.mkdirSync(dstDir, { recursive: true });

function human(bytes) {
  if (bytes < 1024) return bytes + ' B';
  if (bytes < 1024 * 1024) return (bytes / 1024).toFixed(1) + ' KB';
  return (bytes / 1024 / 1024).toFixed(2) + ' MB';
}

const okList = [];
const badList = [];
const failList = [];
const startedAt = Date.now();

console.log('');
console.log('批量解密：' + srcDir);
console.log('       →  ' + dstDir);
console.log('  ─────────────────────────────────────────────');

files.forEach(function (file, index) {
  // 去掉结尾的 .png，还原成加密前的文件名
  const restoredName = file.rel.slice(0, -4);
  const outFile = path.join(dstDir, restoredName);
  fs.mkdirSync(path.dirname(outFile), { recursive: true });

  const args = ['-i', file.full, '-o', outFile, '--json'];
  if (opts.force) args.push('-f');

  const res = spawnSync(process.execPath, [DECRYPT].concat(args), { encoding: 'utf8' });
  const firstError = (res.stderr || '').trim().split('\n')[0];

  // 退出码 3 = 校验和不匹配（数据可能受损），此时文件仍然写出来了
  if (res.status !== 0 && res.status !== 3) {
    failList.push({ file: file.rel, reason: firstError || ('退出码 ' + res.status) });
    if (!opts.quiet) console.log('  ✘ ' + file.rel + '  ' + (firstError || '处理失败'));
    return;
  }

  let info;
  try {
    info = JSON.parse(res.stdout);
  } catch (err) {
    failList.push({ file: file.rel, reason: '无法解析解密结果' });
    if (!opts.quiet) console.log('  ✘ ' + file.rel + '  无法解析解密结果');
    return;
  }

  if (info.checksumOk) {
    okList.push({ file: file.rel, out: outFile, bytes: info.bytes });
    if (!opts.quiet) {
      console.log('  [' + (index + 1) + '/' + files.length + '] ' + file.rel + ' → ' +
        path.basename(outFile) + '  ' + human(info.bytes) + '  ' + info.checksum + ' ✔');
    }
  } else {
    badList.push({ file: file.rel, out: outFile, bytes: info.bytes });
    console.log('  ⚠ ' + file.rel + ' → ' + path.basename(outFile) + '  校验和不匹配，数据可能已受损（已按原样还原）');
  }
});

/* ---------- 汇总 ---------- */
const totalBytes = okList.concat(badList).reduce(function (s, x) { return s + x.bytes; }, 0);
const seconds = ((Date.now() - startedAt) / 1000).toFixed(1);

console.log('  ─────────────────────────────────────────────');
console.log('  成功 ' + okList.length + ' 个 / 校验异常 ' + badList.length + ' 个 / 失败 ' + failList.length +
  ' 个 · 用时 ' + seconds + ' 秒');
if (okList.length || badList.length) console.log('  合计还原 ' + human(totalBytes));
if (failList.length) {
  console.log('');
  console.log('  失败明细：');
  failList.forEach(function (f) { console.log('    ' + f.file + '：' + f.reason); });
}
if (badList.length) {
  console.log('');
  console.log('  校验异常（图片可能在传输中被压缩或修改过）：');
  badList.forEach(function (f) { console.log('    ' + f.file); });
}
console.log('');

process.exit(failList.length || badList.length ? 2 : 0);
