#!/usr/bin/env node
/**
 * RGB 像素隐写 · 解密脚本（命令行版）
 *
 * 读取本工具生成的加密 PNG，按颜色字典还原出原始数据。
 *
 * 用法：
 *   node decrypt.mjs -i <加密图片> -o <保存位置> [选项]
 *   node decrypt.mjs <加密图片> <保存位置>
 *
 * 选项：
 *   -i, --input  <图片>   要解密的 PNG（- 表示从标准输入读取）
 *   -o, --output <路径>   保存位置；- 表示输出到标准输出
 *   -f, --force           覆盖已存在的输出文件
 *   -q, --quiet           只输出结果路径
 *       --stdout          把还原内容直接打印到标准输出（文本用）
 *       --json            以 JSON 输出完整结果
 *   -h, --help            显示帮助
 *   -V, --version         显示版本
 *
 * 退出码：0 成功 / 1 用法错误 / 2 读写失败 / 3 校验和不匹配（数据可能受损）
 */
import fs from 'node:fs';
import path from 'node:path';
import { CODEC } from './lib/codec.mjs';
import { readPng } from './lib/png.mjs';
import { EX } from './lib/cli-common.mjs';

const VERSION = '1.0.0';

const USAGE = `
RGB 像素隐写 · 解密脚本  v${VERSION}

从加密 PNG 中还原出原始数据。

用法
  node decrypt.mjs -i <加密图片> -o <保存位置> [选项]
  node decrypt.mjs <加密图片> <保存位置>

选项
  -i, --input  <图片>   要解密的 PNG；用 - 表示从标准输入读取
  -o, --output <路径>   保存位置；用 - 表示输出到标准输出
  -f, --force           覆盖已存在的输出文件
  -q, --quiet           只输出结果路径
      --stdout          把还原内容直接打印到标准输出
      --json            以 JSON 输出完整结果
  -h, --help            显示本帮助
  -V, --version         显示版本

示例
  node decrypt.mjs -i ${EX.out('合同.png')} -o ${EX.back('合同.pdf')}
  node decrypt.mjs -i ${EX.out('hello.png')} --stdout
  node decrypt.mjs ${EX.out('hello.png')} ${EX.back('hello.txt')}
`.trimStart();

function usageError(message) {
  console.error('参数错误：' + message);
  console.error('运行 node decrypt.mjs --help 查看用法。');
  process.exit(1);
}

function fail(message) {
  console.error('解密失败：' + message);
  process.exit(2);
}

function parseArgs(argv) {
  const opts = { input: null, output: null, force: false, quiet: false, json: false, stdout: false };
  const positional = [];

  for (let i = 0; i < argv.length; i++) {
    let key = argv[i];
    let inline = null;
    if (key.startsWith('--') && key.indexOf('=') > 0) {
      const eq = key.indexOf('=');
      inline = key.slice(eq + 1);
      key = key.slice(0, eq);
    }
    const take = function () {
      if (inline !== null) return inline;
      const next = argv[++i];
      if (next === undefined) usageError('选项 ' + key + ' 缺少参数值');
      return next;
    };

    switch (key) {
      case '-i': case '--input': opts.input = take(); break;
      case '-o': case '--output': case '--out': opts.output = take(); break;
      case '-f': case '--force': opts.force = true; break;
      case '-q': case '--quiet': opts.quiet = true; break;
      case '--json': opts.json = true; break;
      case '--stdout': opts.stdout = true; break;
      case '-h': case '--help': console.log(USAGE); process.exit(0); break;
      case '-V': case '--version': console.log(VERSION); process.exit(0); break;
      default:
        if (key.length > 1 && key.charAt(0) === '-') usageError('未知选项：' + key);
        positional.push(argv[i]);
    }
  }

  if (opts.input === null && positional.length) opts.input = positional.shift();
  if (opts.output === null && positional.length) opts.output = positional.shift();
  if (positional.length) usageError('多余的参数：' + positional.join(' '));
  return opts;
}

function main() {
  const opts = parseArgs(process.argv.slice(2));

  if (opts.input === null) usageError('请用 -i/--input 指定要解密的加密图片。');
  if (opts.output === null && !opts.stdout && !opts.json) {
    usageError('请用 -o/--output 指定保存位置（或用 --stdout 打印到标准输出）。');
  }

  let buf;
  let inputLabel;
  if (opts.input === '-') {
    try { buf = fs.readFileSync(0); } catch (err) { fail('读取标准输入失败：' + err.message); }
    inputLabel = '标准输入';
  } else {
    const file = path.resolve(opts.input);
    try {
      if (!fs.statSync(file).isFile()) fail('不是文件：' + opts.input);
    } catch (err) {
      fail(err.code === 'ENOENT' ? '找不到图片文件：' + opts.input : err.message);
    }
    try { buf = fs.readFileSync(file); } catch (err) { fail('读取图片失败：' + err.message); }
    inputLabel = file;
  }

  let png;
  try {
    png = readPng(buf);
  } catch (err) {
    fail(err.message + '\n  本脚本只支持 8 位 RGBA 的 PNG（即本工具生成的图片）。');
  }

  const result = CODEC.decode(png.data, png.width, png.height);
  if (!result.ok) fail(result.error);

  const meta = result.meta;
  const bytes = result.bytes;

  // 还原内容判断：优先按文本处理
  let text = null;
  let isUtf8 = false;
  try {
    text = new TextDecoder('utf-8', { fatal: true }).decode(bytes);
    isUtf8 = true;
  } catch (err) { /* 二进制内容 */ }

  /* ---- 输出数据 ---- */
  const toStdout = opts.stdout || opts.output === '-';
  let writtenTo = null;
  if (toStdout) {
    process.stdout.write(Buffer.from(bytes));
  } else if (opts.output !== null) {
    // 注意：--json 也应照常写出文件，否则无法在脚本里既拿到结果又拿到数据
    const target = path.resolve(String(opts.output));
    if (fs.existsSync(target) && !opts.force) {
      fail('输出文件已存在：' + target + '\n  如需覆盖请加 -f/--force。');
    }
    try {
      const dir = path.dirname(target);
      if (!fs.existsSync(dir)) fs.mkdirSync(dir, { recursive: true });
      fs.writeFileSync(target, Buffer.from(bytes));
      writtenTo = target;
    } catch (err) {
      fail('写入文件失败：' + err.message);
    }
  }

  const summary = {
    ok: true,
    input: inputLabel,
    inputPixels: png.width + 'x' + png.height,
    output: toStdout ? '-' : writtenTo,
    bytes: bytes.length,
    blockSize: meta.blockSize,
    declaredBlockSize: meta.declaredBlock,
    cols: meta.cols,
    rows: meta.rows,
    checksum: '0x' + meta.checksumActual.toString(16).toUpperCase().padStart(8, '0'),
    checksumOk: meta.checksumOk,
    warnings: result.warnings,
    text: isUtf8 ? text : null
  };

  if (!opts.json && !opts.quiet && !toStdout) {
    const out = [];
    out.push('');
    out.push('RGB 像素隐写 · 解密完成');
    out.push('  ─────────────────────────────────────────────');
    out.push('  图片      ' + inputLabel + '（' + png.width + ' × ' + png.height + ' px）');
    out.push('  像素块    ' + meta.blockSize + '×' + meta.blockSize + '（文件头声明 ' + meta.declaredBlock + '×' + meta.declaredBlock + '）');
    out.push('  数据长度  ' + bytes.length.toLocaleString('en-US') + ' 字节');
    out.push('  校验和    ' + summary.checksum + (meta.checksumOk ? '  ✔ 与文件头一致，数据完整' : '  ✘ 数据可能受损'));
    result.warnings.forEach(function (w) { out.push('  注意      ' + w); });
    if (isUtf8 && /^[\s\S]{0,400}$/.test(text)) {
      out.push('  内容预览  ' + JSON.stringify(text.length > 120 ? text.slice(0, 120) + '…' : text));
    }
    out.push('');
    console.log(out.join('\n'));
  } else if (opts.json) {
    console.log(JSON.stringify(summary));
  } else if (opts.quiet && !toStdout) {
    console.log(summary.output);
  }

  if (!meta.checksumOk) process.exit(3);
}

main();
