#!/bin/sh
# RGB 像素隐写工具 · 图形界面启动器（Linux / macOS）
#
# 在本机启动一个只监听 127.0.0.1 的静态服务，并用默认浏览器打开工具页面。
# 用本地地址是为了让浏览器把它当作安全上下文，从而支持「另存为」对话框
# （自定义保存位置与文件名）。
#
# 用法：
#   ./rgb-stego.sh                启动并自动打开浏览器
#   ./rgb-stego.sh --no-open      只启动服务，不打开浏览器
#   ./rgb-stego.sh --port 9000    指定端口（默认自动挑一个空闲端口）
#
# 按 Ctrl+C 停止服务。
#
# 本脚本是 POSIX sh 语法（不用 bash 扩展），dash / bash / busybox ash 均可运行。

set -eu

# 取脚本自身所在目录；被软链接调用时先解析到真实文件（~/.local/bin/rgb-stego 就是这样）
SELF=$0
while [ -h "$SELF" ]; do
  LINK=$(readlink "$SELF")
  case $LINK in
    /*) SELF=$LINK ;;
    *) SELF=$(dirname -- "$SELF")/$LINK ;;
  esac
done
DIR=$(CDPATH= cd -- "$(dirname -- "$SELF")" && pwd)

if ! command -v node >/dev/null 2>&1; then
  echo "错误：未找到 Node.js。" >&2
  echo "请先安装 Node.js 18 或更高版本：https://nodejs.org" >&2
  exit 1
fi

NODE_MAJOR=$(node -e 'process.stdout.write(String(process.versions.node.split(".")[0]))')
if [ "$NODE_MAJOR" -lt 18 ] 2>/dev/null; then
  echo "提示：当前 Node.js 版本为 $(node -v)，建议升级到 18 或更高。" >&2
fi

if [ ! -f "$DIR/server.mjs" ]; then
  echo "错误：找不到 $DIR/server.mjs，文件可能不完整。" >&2
  exit 1
fi

exec node "$DIR/server.mjs" "$@"
