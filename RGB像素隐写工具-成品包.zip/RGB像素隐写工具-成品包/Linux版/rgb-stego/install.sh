#!/bin/sh
# RGB 像素隐写工具 · 安装脚本（Linux / macOS）
#
# 把程序复制到 ~/.local/share/rgb-stego，并创建命令行入口与桌面菜单项：
#
#   ~/.local/bin/rgb-stego                    图形界面
#   ~/.local/bin/rgb-stego-encrypt            加密
#   ~/.local/bin/rgb-stego-decrypt            解密
#   ~/.local/bin/rgb-stego-batch-encrypt      批量加密
#   ~/.local/bin/rgb-stego-batch-decrypt      批量解密
#   ~/.local/share/applications/rgb-stego.desktop    桌面菜单项（Linux）
#
# 用法：
#   sh install.sh              安装 / 覆盖安装
#   sh install.sh --uninstall  卸载（只删本工具自己的文件）
#   sh install.sh --help       帮助
#
# 只动用户目录，不需要 root，也不会修改系统文件。

set -eu

PREFIX_DIR="${XDG_DATA_HOME:-$HOME/.local/share}"
APP_DIR="$PREFIX_DIR/rgb-stego"
BIN_DIR="$HOME/.local/bin"
MENU_DIR="$PREFIX_DIR/applications"
DESKTOP_FILE="$MENU_DIR/rgb-stego.desktop"

SELF=$0
while [ -h "$SELF" ]; do
  LINK=$(readlink "$SELF")
  case $LINK in
    /*) SELF=$LINK ;;
    *) SELF=$(dirname -- "$SELF")/$LINK ;;
  esac
done
SRC_DIR=$(CDPATH= cd -- "$(dirname -- "$SELF")" && pwd)

BIN_LINKS="rgb-stego rgb-stego-encrypt rgb-stego-decrypt rgb-stego-batch-encrypt rgb-stego-batch-decrypt"

usage() {
  echo "用法： sh install.sh [--uninstall]"
  echo ""
  echo "  （无参数）      安装到 $APP_DIR"
  echo "  --uninstall,-u  卸载"
}

uninstall() {
  echo "正在卸载…"
  for name in $BIN_LINKS; do
    rm -f "$BIN_DIR/$name"
  done
  rm -f "$DESKTOP_FILE"
  rm -rf "$APP_DIR"
  if command -v update-desktop-database >/dev/null 2>&1; then
    update-desktop-database "$MENU_DIR" >/dev/null 2>&1 || true
  fi
  echo "已卸载："
  echo "  删除目录  $APP_DIR"
  echo "  删除入口  $BIN_DIR/{$(echo $BIN_LINKS | tr ' ' ',')}"
  echo "  删除菜单项 $DESKTOP_FILE"
}

case "${1:-}" in
  --uninstall|-u) uninstall; exit 0 ;;
  --help|-h) usage; exit 0 ;;
  "") ;;
  *) echo "未知参数：$1" >&2; usage >&2; exit 1 ;;
esac

if ! command -v node >/dev/null 2>&1; then
  echo "错误：未找到 Node.js。" >&2
  echo "请先安装 Node.js 18 或更高版本，然后重新执行本脚本。" >&2
  echo "  Debian/Ubuntu： sudo apt install nodejs" >&2
  echo "  Fedora：        sudo dnf install nodejs" >&2
  echo "  Arch：          sudo pacman -S nodejs" >&2
  echo "  其它 / 最新版： https://nodejs.org" >&2
  exit 1
fi

echo "Node.js：$(node -v)   （$(command -v node)）"

if [ ! -f "$SRC_DIR/server.mjs" ] || [ ! -f "$SRC_DIR/index.html" ]; then
  echo "错误：$SRC_DIR 里找不到 server.mjs / index.html，请在解压后的目录里运行本脚本。" >&2
  exit 1
fi

echo "安装到 $APP_DIR …"
mkdir -p "$APP_DIR" "$BIN_DIR"

# 用 cp -R 源目录内容覆盖，保持目录结构（lib/、samples/）
cp -R "$SRC_DIR/." "$APP_DIR/"

chmod +x "$APP_DIR/rgb-stego.sh" "$APP_DIR/install.sh" "$APP_DIR/uninstall.sh" 2>/dev/null || true
for f in "$APP_DIR"/*.mjs; do
  [ -f "$f" ] && chmod +x "$f"
done

# 命令行入口
ln -sf "$APP_DIR/rgb-stego.sh" "$BIN_DIR/rgb-stego"
ln -sf "$APP_DIR/encrypt.mjs" "$BIN_DIR/rgb-stego-encrypt"
ln -sf "$APP_DIR/decrypt.mjs" "$BIN_DIR/rgb-stego-decrypt"
ln -sf "$APP_DIR/batch-encrypt.mjs" "$BIN_DIR/rgb-stego-batch-encrypt"
ln -sf "$APP_DIR/batch-decrypt.mjs" "$BIN_DIR/rgb-stego-batch-decrypt"

# 桌面菜单项（把占位符替换成实际安装路径）
if [ -f "$APP_DIR/rgb-stego.desktop" ]; then
  mkdir -p "$MENU_DIR"
  sed "s|@APP_DIR@|$APP_DIR|g" "$APP_DIR/rgb-stego.desktop" > "$DESKTOP_FILE"
  chmod +x "$DESKTOP_FILE" 2>/dev/null || true
  if command -v update-desktop-database >/dev/null 2>&1; then
    update-desktop-database "$MENU_DIR" >/dev/null 2>&1 || true
  fi
fi

echo ""
echo "安装完成。"
echo ""
echo "  图形界面： rgb-stego            （或在应用菜单里找「RGB 像素隐写工具」）"
echo "  加密：     rgb-stego-encrypt -i 文件 -o 输出.png"
echo "  解密：     rgb-stego-decrypt -i 输出.png -o 文件"
echo "  批量加密： rgb-stego-batch-encrypt <源目录> <输出目录> -r"
echo "  批量解密： rgb-stego-batch-decrypt <图片目录> <还原目录> -r"
echo ""
echo "  帮助：     rgb-stego-encrypt --help"
echo "  卸载：     sh $APP_DIR/install.sh --uninstall"

case ":$PATH:" in
  *":$BIN_DIR:"*) ;;
  *)
    echo ""
    echo "提示：$BIN_DIR 不在 PATH 里，上面的命令暂时无法直接使用。"
    echo "      把下面这行加到 ~/.profile 或 ~/.bashrc 后重新打开终端即可："
    echo ""
    echo "        export PATH=\"\$HOME/.local/bin:\$PATH\""
    ;;
esac
