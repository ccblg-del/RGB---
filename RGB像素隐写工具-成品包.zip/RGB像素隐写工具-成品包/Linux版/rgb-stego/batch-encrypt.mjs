#!/usr/bin/env node
/**
 * 批量加密脚本
 *
 * 把一个文件夹里的每个文件，各自加密成一张 PNG，放到输出文件夹里。
 * 输出文件名 = 原文件名 + .png，例如 合同.pdf → 合同.pdf.png，便于批量解密时还原原名。
 *
 * 用法：
 *   node batch-encrypt.mjs <源文件夹> <输出文件夹> [选项]
 *
 * 选项：
 *   -b, --block <1-16>   像素块大小，默认 4（1 = 1 个字符只占 1 个像素）
 *   -f, --force          覆盖已存在的输出文件
 *   -r, --recursive      连同子文件夹一起处理（保持相对目录结构）
 *   -q, --quiet          只输出汇总，不逐条打印
 *   -h, --help           显示帮助
 *
 * 退出码：0 全部成功 / 1 用法错误 / 2 有文件处理失败
 */
import fs from 'node:fs';
import path from 'node:path';
import { spawnSync } from 'node:child_process';
import { fileURLToPath } from 'node:url';
import { EX } from './lib/cli-common.mjs';

const here = path.dirname(fileURLToPath(import.meta.url));
const ENCRYPT = path.join(here, 'encrypt.mjs');

const USAGE = `
批量加密脚本

用法
  node batch-encrypt.mjs <源文件夹> <输出文件夹> [选项]

选项
  -b, --block <1-16>   像素块大小，默认 4（1 = 1 个字符只占 1 个像素）
  -f, --force          覆盖已存在的输出文件
  -r, --recursive      连同子文件夹一起处理（保持相对目录结构）
  -q, --quiet          只输出汇总
  -h, --help           显示本帮助

示例
  node batch-encrypt.mjs ${EX.inDir} ${EX.outDir}
  node batch-encrypt.mjs ${EX.inDir} ${EX.outDir} -b 8 -f
  node batch-encrypt.mjs ${EX.inDir} ${EX.outDir} -r
`.trimStart();

function usageError(msg) {
  console.error('参数错误：' + msg);
  console.error('运行 node batch-encrypt.mjs --help 查看用法。');
  process.exit(1);
}

/* ---------- 参数 ---------- */
const argv = process.argv.slice(2);
const opts = { block: 4, force: false, recursive: false, quiet: false };
const positional = [];

for (let i = 0; i < argv.length; i++) {
  const a = argv[i];
  if (a === '-h' || a === '--help') { console.log(USAGE); process.exit(0); }
  else if (a === '-b' || a === '--block') { opts.block = argv[++i]; }
  else if (a === '-f' || a === '--force') { opts.force = true; }
  else if (a === '-r' || a === '--recursive') { opts.recursive = true; }
  else if (a === '-q' || a === '--quiet') { opts.quiet = true; }
  else if (a.startsWith('-') && a.length > 1) { usageError('未知选项：' + a); }
  else { positional.push(a); }
}

if (positional.length < 2) usageError('需要指定 <源文件夹> 和 <输出文件夹>。');
if (positional.length > 2) usageError('多余的参数：' + positional.slice(2).join(' '));

const blockSize = Number(opts.block);
if (!Number.isInteger(blockSize) || blockSize < 1 || blockSize > 16) {
  usageError('--block 必须是 1–16 之间的整数，当前为 ' + opts.block);
}

const srcDir = path.resolve(positional[0]);
const dstDir = path.resolve(positional[1]);

if (!fs.existsSync(srcDir)) { console.error('找不到源文件夹：' + srcDir); process.exit(2); }
if (!fs.statSync(srcDir).isDirectory()) { console.error('不是文件夹：' + srcDir); process.exit(2); }

/* ---------- 收集文件 ---------- */
function collect(dir, base, out) {
  for (const entry of fs.readdirSync(dir, { withFileTypes: true })) {
    const full = path.join(dir, entry.name);
    const rel = base ? path.join(base, entry.name) : entry.name;
    if (entry.isDirectory()) {
      if (opts.recursive) collect(full, rel, out);
    } else if (entry.isFile()) {
      out.push({ full: full, rel: rel, size: fs.statSync(full).size });
    }
  }
  return out;
}

const files = collect(srcDir, '', []);
if (files.length === 0) {
  console.error('源文件夹里没有文件：' + srcDir);
  process.exit(2);
}

fs.mkdirSync(dstDir, { recursive: true });

/* ---------- 逐个加密 ---------- */
function human(bytes) {
  if (bytes < 1024) return bytes + ' B';
  if (bytes < 1024 * 1024) return (bytes / 1024).toFixed(1) + ' KB';
  return (bytes / 1024 / 1024).toFixed(2) + ' MB';
}

const okList = [];
const failList = [];
const startedAt = Date.now();

console.log('');
console.log('批量加密：' + srcDir);
console.log('       →  ' + dstDir + '（像素块 ' + blockSize + '×' + blockSize + '）');
console.log('  ─────────────────────────────────────────────');

files.forEach(function (file, index) {
  const outFile = path.join(dstDir, file.rel + '.png');
  fs.mkdirSync(path.dirname(outFile), { recursive: true });

  const args = ['-i', file.full, '-o', outFile, '-b', String(blockSize), '--json'];
  if (opts.force) args.push('-f');

  const res = spawnSync(process.execPath, [ENCRYPT].concat(args), { encoding: 'utf8' });

  if (res.status !== 0) {
    failList.push({ file: file.rel, reason: (res.stderr || '').trim().split('\n')[0] || ('退出码 ' + res.status) });
    console.log('  ✘ ' + file.rel + '  ' + failList[failList.length - 1].reason);
    return;
  }

  let info;
  try {
    info = JSON.parse(res.stdout);
  } catch (err) {
    failList.push({ file: file.rel, reason: '无法解析加密结果' });
    console.log('  ✘ ' + file.rel + '  无法解析加密结果');
    return;
  }

  okList.push({ file: file.rel, out: outFile, inputBytes: info.inputBytes, outputBytes: info.outputBytes, width: info.width, height: info.height, checksum: info.checksum });
  if (!opts.quiet) {
    console.log('  [' + (index + 1) + '/' + files.length + '] ' + file.rel +
      '  ' + human(info.inputBytes) + ' → ' + path.basename(outFile) +
      '  ' + info.width + '×' + info.height + ' px  ' + info.checksum);
  }
});

/* ---------- 汇总 ---------- */
const totalIn = okList.reduce(function (s, x) { return s + x.inputBytes; }, 0);
const totalOut = okList.reduce(function (s, x) { return s + x.outputBytes; }, 0);
const seconds = ((Date.now() - startedAt) / 1000).toFixed(1);

console.log('  ─────────────────────────────────────────────');
console.log('  成功 ' + okList.length + ' 个 / 失败 ' + failList.length + ' 个 · 用时 ' + seconds + ' 秒');
if (okList.length) console.log('  合计 ' + human(totalIn) + ' → ' + human(totalOut) + '（' + okList.length + ' 张 PNG）');
if (failList.length) {
  console.log('');
  console.log('  失败明细：');
  failList.forEach(function (f) { console.log('    ' + f.file + '：' + f.reason); });
}
console.log('');
console.log('  解密：node batch-decrypt.mjs "' + dstDir + '" <还原文件夹>');
console.log('');

process.exit(failList.length ? 2 : 0);
