#!/usr/bin/env node
/**
 * RGB 像素隐写 · 加密脚本（命令行版）
 *
 * 把任意文件或一段文本，用 R/G/B 三原色编码进图片的像素点，生成一张 PNG。
 * 需要加密的文件、保存位置全部通过命令行指定。
 *
 * 用法：
 *   node encrypt.mjs -i <要加密的文件> -o <保存位置> [选项]
 *   node encrypt.mjs <要加密的文件> <保存位置>            # 位置参数写法
 *
 * 选项：
 *   -i, --input  <文件>    要加密的文件；- 表示从标准输入读取
 *   -o, --output <路径>    保存位置：PNG 文件路径，或目录（自动命名）
 *   -t, --text   <文本>    直接加密一段文本（与 -i 二选一）
 *   -b, --block  <1-16>    像素块大小，默认 4（1 = 1 个字符只占 1 个像素）
 *   -c, --cols   <数量>    每行像素块数，默认自动排成方形
 *   -f, --force            覆盖已存在的输出文件
 *   -q, --quiet            只输出结果路径
 *       --json             以 JSON 输出完整结果（便于脚本调用）
 *   -h, --help             显示帮助
 *   -V, --version          显示版本
 *
 * 退出码：0 成功 / 1 用法错误 / 2 读写或编码失败
 */
import fs from 'node:fs';
import path from 'node:path';
import { CODEC } from './lib/codec.mjs';
import { writePng } from './lib/png.mjs';
import { EX, IS_WINDOWS } from './lib/cli-common.mjs';

const VERSION = '1.0.0';
const DEFAULT_BLOCK_SIZE = 4;   // 默认像素块大小（如需改默认值，改这一行即可）
const PIPE_CMD = IS_WINDOWS ? 'type secret.txt' : 'cat secret.txt';
const BROWSER_MAX_SIDE = 16384; // 主流浏览器 canvas 边长上限（Chrome 32767 / 其它 16384），超过则页面端无法解码

const USAGE = `
RGB 像素隐写 · 加密脚本  v${VERSION}

把文件或文本编码进图片的像素颜色，生成一张 PNG。

用法
  node encrypt.mjs -i <要加密的文件> -o <保存位置> [选项]
  node encrypt.mjs <要加密的文件> <保存位置>

选项
  -i, --input  <文件>    要加密的文件；用 - 表示从标准输入读取
  -o, --output <路径>    保存位置：PNG 文件路径，或目录（目录内自动命名）
  -t, --text   <文本>    直接加密一段文本（与 -i 二选一）
  -b, --block  <1-16>    像素块大小，默认 4（1 = 1 个字符只占 1 个像素）
  -c, --cols   <数量>    每行像素块数，默认自动排成方形
  -f, --force            覆盖已存在的输出文件
  -q, --quiet            只输出结果路径
      --json             以 JSON 输出完整结果（便于脚本调用）
  -h, --help             显示本帮助
  -V, --version          显示版本

保存位置的写法
  -o ${EX.out('合同.png')}    写到这个文件（上级目录不存在会自动创建）
  -o ${EX.outDirSlash}              末尾带分隔符 → 写到该目录，自动命名为 <输入文件名>-stego.png
  -o ${EX.outDir}                已经是目录 → 同上（自动命名）
  -o ${EX.out('合同')}        不是目录 → 按文件处理，缺 .png 时自动补上

  规则：末尾带分隔符、或本身已是目录 → 目录；其余一律当作文件路径。
  实际写入的完整路径会在结果里打印出来。

示例
  node encrypt.mjs -i ${EX.file} -o ${EX.out('合同.png')}
  node encrypt.mjs -i photo.jpg -o ${EX.outDirSlash} -b 8
  node encrypt.mjs -t "hello" -o ${EX.out('hello.png')}
  ${PIPE_CMD} | node encrypt.mjs -i - -o ${EX.out('secret.png')}

说明
  每个字节对应一个像素块（块内像素同色）：高 3 位 → R，中 3 位 → G，低 2 位 → B，
  色码共 8×8×4 = 256 种互不重复的组合，覆盖 ASCII 全表 0–127 与全部字节 0–255。
  生成的 PNG 必须原样保存，截图或有损压缩会导致无法还原。
`.trimStart();

function usageError(message) {
  console.error('参数错误：' + message);
  console.error('运行 node encrypt.mjs --help 查看用法。');
  process.exit(1);
}

function fail(message) {
  console.error('加密失败：' + message);
  process.exit(2);
}

/* ---------------- 参数解析 ---------------- */

function parseArgs(argv) {
  const opts = {
    input: null, output: null, text: null,
    block: DEFAULT_BLOCK_SIZE, cols: 0, force: false, quiet: false, json: false
  };
  const positional = [];

  for (let i = 0; i < argv.length; i++) {
    let key = argv[i];
    let inline = null;

    if (key.startsWith('--') && key.indexOf('=') > 0) {
      const eq = key.indexOf('=');
      inline = key.slice(eq + 1);
      key = key.slice(0, eq);
    }

    const take = function () {
      if (inline !== null) return inline;
      const next = argv[++i];
      if (next === undefined) usageError('选项 ' + key + ' 缺少参数值');
      return next;
    };

    switch (key) {
      case '-i': case '--input': opts.input = take(); break;
      case '-o': case '--output': case '--out': opts.output = take(); break;
      case '-t': case '--text': opts.text = take(); break;
      case '-b': case '--block': opts.block = take(); break;
      case '-c': case '--cols': opts.cols = take(); break;
      case '-f': case '--force': opts.force = true; break;
      case '-q': case '--quiet': opts.quiet = true; break;
      case '--json': opts.json = true; break;
      case '-h': case '--help': console.log(USAGE); process.exit(0); break;
      case '-V': case '--version': console.log(VERSION); process.exit(0); break;
      default:
        if (key.length > 1 && key.charAt(0) === '-') usageError('未知选项：' + key);
        positional.push(argv[i]);
    }
  }

  // 位置参数：encrypt.mjs <输入文件> <保存位置>
  if (opts.input === null && opts.text === null && positional.length) opts.input = positional.shift();
  if (opts.output === null && positional.length) opts.output = positional.shift();
  if (positional.length) usageError('多余的参数：' + positional.join(' '));

  return opts;
}

/* ---------------- 输入读取 ---------------- */

function readInput(opts) {
  if (opts.text !== null) {
    const bytes = new Uint8Array(Buffer.from(opts.text, 'utf8'));
    return { bytes: bytes, label: '命令行文本', name: 'text' };
  }
  if (opts.input === null) {
    usageError('请用 -i/--input 指定要加密的文件（或用 -t/--text 指定文本）。');
  }
  if (opts.input === '-') {
    let bytes;
    try {
      bytes = new Uint8Array(fs.readFileSync(0));
    } catch (err) {
      fail('读取标准输入失败：' + err.message);
    }
    return { bytes: bytes, label: '标准输入', name: 'stdin' };
  }

  const file = path.resolve(opts.input);
  let stat;
  try {
    stat = fs.statSync(file);
  } catch (err) {
    fail('找不到要加密的文件：' + opts.input);
  }
  if (!stat.isFile()) fail('不是文件：' + opts.input);

  let bytes;
  try {
    bytes = new Uint8Array(fs.readFileSync(file));
  } catch (err) {
    fail('读取文件失败：' + err.message);
  }
  if (bytes.length === 0) fail('文件内容为空：' + opts.input);
  return { bytes: bytes, label: file, name: path.basename(file, path.extname(file)) || 'output' };
}

/* ---------------- 输出位置解析 ---------------- */

function resolveOutput(output, baseName) {
  if (output === null || output === undefined || String(output).trim() === '') {
    usageError('请用 -o/--output 指定保存位置。');
  }

  let target = path.resolve(String(output));
  let isDir = false;

  try {
    if (fs.statSync(target).isDirectory()) isDir = true;
  } catch (err) { /* 不存在，按下面的规则判断 */ }

  if (/[\\/]$/.test(String(output))) isDir = true;

  if (isDir) target = path.join(target, baseName + '-stego.png');
  else if (path.extname(target).toLowerCase() !== '.png') target += '.png';

  return target;
}

/* ---------------- 主流程 ---------------- */

function main() {
  const opts = parseArgs(process.argv.slice(2));

  const blockSize = Number(opts.block);
  if (!Number.isInteger(blockSize) || blockSize < 1 || blockSize > CODEC.MAX_BLOCK) {
    usageError('--block 必须是 1–' + CODEC.MAX_BLOCK + ' 之间的整数，当前为 ' + opts.block);
  }

  let cols = Number(opts.cols);
  if (!Number.isFinite(cols) || cols < 0) usageError('--cols 必须是不小于 0 的整数，当前为 ' + opts.cols);
  cols = Math.floor(cols);
  if (cols > CODEC.MAX_COLS) usageError('--cols 不能超过 ' + CODEC.MAX_COLS + '（文件头用 2 字节存每行块数）');

  const input = readInput(opts);
  const target = resolveOutput(opts.output, input.name);

  if (fs.existsSync(target) && !opts.force) {
    fail('输出文件已存在：' + target + '\n  如需覆盖请加 -f/--force。');
  }

  const payload = input.bytes;
  const result = CODEC.encode(payload, { blockSize: blockSize, cols: cols });

  if (result.width > BROWSER_MAX_SIDE || result.height > BROWSER_MAX_SIDE) {
    console.error('警告：图片边长 ' + result.width + '×' + result.height + ' px 超过浏览器的画布上限（' +
      BROWSER_MAX_SIDE + '），网页版可能无法打开，建议用 -b 1 减小尺寸。');
  } else if (payload.length > 1024 * 1024) {
    console.error('提示：数据量较大（' + payload.length + ' 字节），生成的图片为 ' +
      result.width + '×' + result.height + ' px，解码需要相应内存。');
  }

  let png;
  try {
    png = writePng(result.width, result.height, result.data);
  } catch (err) {
    fail('生成 PNG 失败：' + err.message);
  }

  try {
    const dir = path.dirname(target);
    if (!fs.existsSync(dir)) {
      fs.mkdirSync(dir, { recursive: true });
      if (!opts.quiet && !opts.json) console.log('已创建目录：' + dir);
    }
    fs.writeFileSync(target, png);
  } catch (err) {
    fail('写入文件失败：' + err.message);
  }

  const summary = {
    ok: true,
    input: input.label,
    inputBytes: payload.length,
    output: target,
    outputBytes: png.length,
    width: result.width,
    height: result.height,
    blockSize: result.blockSize,
    cols: result.cols,
    rows: result.rows,
    blocks: result.cols * result.rows,
    checksum: '0x' + result.checksum.toString(16).toUpperCase().padStart(8, '0')
  };

  if (opts.json) {
    console.log(JSON.stringify(summary));
    return;
  }
  if (opts.quiet) {
    console.log(target);
    return;
  }

  const out = [];
  out.push('');
  out.push('RGB 像素隐写 · 加密完成');
  out.push('  ─────────────────────────────────────────────');
  out.push('  输入      ' + input.label + '（' + payload.length.toLocaleString('en-US') + ' 字节）');
  out.push('  保存位置  ' + target + '（' + png.length.toLocaleString('en-US') + ' 字节）');
  out.push('  图片      ' + result.width + ' × ' + result.height + ' px · 像素块 ' +
    result.blockSize + '×' + result.blockSize + ' · 网格 ' + result.cols + ' 块/行 × ' + result.rows + ' 行');
  out.push('  校验和    FNV-1a ' + summary.checksum + '（解密时会比对）');
  out.push('  颜色字典  前 ' + Math.min(payload.length, 6) + ' 个字节：');
  let line = '            ';
  for (let i = 0; i < Math.min(payload.length, 6); i++) {
    const b = payload[i];
    const c = CODEC.codesFromByte(b);
    const rgb = CODEC.rgbFromByte(b);
    const ch = b >= 33 && b <= 126 ? String.fromCharCode(b) : (b < 32 ? '\\x' + b.toString(16).toUpperCase().padStart(2, '0') : '.');
    line += "'" + ch + "'(" + b + ') → (' + c.join(',') + ') → rgb(' + rgb.join(',') + ')   ';
  }
  out.push(line);
  out.push('');
  out.push('  提示：图片需保持 PNG 原图，截图或有损压缩会导致无法还原。');
  out.push('');
  console.log(out.join('\n'));
}

main();
